import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common'; 
import { Trip } from '../models/trip';
import { TripDataService } from '../services/trip-data.service';
import { Router } from '@angular/router';  
import { TripCardComponent } from '../trip-card/trip-card.component';

@Component({
  selector: 'app-trip-listing',
  standalone: true,
  imports: [CommonModule, TripCardComponent],
  templateUrl: './trip-listing.component.html',
  styleUrls: ['./trip-listing.component.css'],
  providers: [TripDataService]
})
export class TripListingComponent implements OnInit {
  public trips: Trip[] = [];  // Initialize the trips array correctly
  public message: string = '';

  constructor(
    private tripDataService: TripDataService,
    private router: Router
  ) {
    console.log('trip-listing constructor');
  }

  // Method to navigate to the add-trip page
  public addTrip(): void {
    console.log('Add new trip clicked!');
    this.router.navigate(['/add-trip']);
  }

  // OnInit lifecycle hook to get trips data
  ngOnInit(): void {
    console.log('ngOnInit');
    this.getTrips();
  }

  // Get trips data from the TripDataService
  private getTrips(): void {
    this.tripDataService.getTrips().subscribe({
      next: (value: Trip[]) => {
        this.trips = value;  // Assign retrieved trips to the array
        if (this.trips.length > 0) {
          this.message = `There are ${this.trips.length} trips available.`;  // Message based on trips length
        } else {
          this.message = 'There were no trips retrieved from the database';
        }
        console.log(this.message);
      },
      error: (error: any) => {
        console.log('Error:', error);  // Log the error
      }
    });
  }
}
