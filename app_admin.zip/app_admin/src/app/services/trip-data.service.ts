import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http"; // Fixed import
import { Observable, catchError, throwError } from "rxjs";
import { Trip } from '../models/trips';

@Injectable({
  providedIn: 'root'
})
export class TripDataService {
  private apiBaseUrl: string = 'http://localhost:3000/api/';
  private tripUrl: string = `${this.apiBaseUrl}trips/`;

  constructor(private http: HttpClient) {}

  public getTrips(): Observable<Trip[]> {
    console.log("Inside TripDataService#getTrips");
    return this.http.get<Trip[]>(this.tripUrl)
      .pipe(catchError(this.handleError));
  }

  public getTrip(tripCode: string): Observable<Trip> {
    console.log("Inside TripDataService#getTrip(tripCode)");
    return this.http.get<Trip>(this.tripUrl + tripCode)
      .pipe(catchError(this.handleError));
  }

  public addTrip(formData: Trip): Observable<Trip> {
    console.log("Inside TripDataService#addTrip");
    return this.http.post<Trip>(this.tripUrl, formData)
      .pipe(catchError(this.handleError));
  }

  public updateTrip(formData: Trip): Observable<Trip> {
    console.log("Inside TripDataService#updateTrip");
    return this.http.put<Trip>(this.tripUrl + formData.code, formData)
      .pipe(catchError(this.handleError));
  }

  public deleteTrip(tripCode: string): Observable<Trip> {
    console.log("Inside TripDataService#deleteTrip");
    return this.http.delete<Trip>(this.tripUrl + tripCode)
      .pipe(catchError(this.handleError));
  }

  private handleError(error: any) {
    console.error("Something has gone wrong", error);
    return throwError(() => error.error || 'Server error');
  }
}
